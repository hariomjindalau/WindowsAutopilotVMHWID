Hardware Information Extract for VM by tech24online.com:
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Capture Hardware Hash from Virtual Machine.
	Copy HWIDVM folder into USB
	Mount USB into Windows 10 virtual machine.
	Go to E:\
	Cd HWIDVM
	type info.bat
	This will open the powershell and collect the information.
	once completed, you can exit the command prompt.
	remove the usb drive.
	file AutopilotHWID.csv is ready.


