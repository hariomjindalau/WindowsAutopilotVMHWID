Set-ExecutionPolicy -Scope Process -ExecutionPolicy Unrestricted
Set-Location E:\\HWIDVM
.\Get-WindowsAutoPilotInfo.ps1 -OutputFile e:\HWIDVM\AutoPilotHWID.csv